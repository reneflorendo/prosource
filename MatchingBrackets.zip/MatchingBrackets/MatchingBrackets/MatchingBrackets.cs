﻿using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace MatchingBracketsConsoleApp
{
    public class MatchingBrackets
    {
        public bool HasMatchingBrackets(string text) {

            //Replace non {} characters
            string result = Regex.Replace(text, "[^{}}]+", "");

            //Check if there are 0 or more braces pairs
            bool isMatch = Regex.IsMatch(result, @"^(\{\})*(\{\{\}\})*$");
            return isMatch;
        }

    }
}
