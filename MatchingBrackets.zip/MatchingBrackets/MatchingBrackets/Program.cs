﻿using System;

namespace MatchingBracketsConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            MatchingBrackets matchingBrackets = new MatchingBrackets();

            Console.WriteLine(matchingBrackets.HasMatchingBrackets("{}"));
            Console.WriteLine(matchingBrackets.HasMatchingBrackets("}{"));
            Console.WriteLine(matchingBrackets.HasMatchingBrackets("{{}"));
            Console.WriteLine(matchingBrackets.HasMatchingBrackets(""));
            Console.WriteLine(matchingBrackets.HasMatchingBrackets("{ abc...xyz}"));
            Console.WriteLine(matchingBrackets.HasMatchingBrackets("{the { quick}brown{{fox}jump{over}}}}the{lazy{{dog}}}}}}}"));

            Console.ReadLine();
        }
    }
}
